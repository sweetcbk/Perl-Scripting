$count=1;
print "Display numbers from 1 to 5";
while($count<=5){
   print $count."\n";
   $count=$count+1;
}
print "End of program";
