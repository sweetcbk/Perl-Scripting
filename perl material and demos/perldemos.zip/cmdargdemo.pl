foreach(@ARGV)
{
print "Hello $_\n";
}
print "enter number";
$num=<>;
print "You entered : $num";
