print "Hello world\n";
print 'Hello world\n';