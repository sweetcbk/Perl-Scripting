$str = "Hw W'II"; 
if ($str =~ m/[aeiou]/) { 
	print "There are vowels"; 
} else { 
	print "\n There are no vowels"; 
}