print("Hello World!\n");
print ('Hello World\n');
print q\Hello word\;
print qq\Hello world!\;