$x=20;
$y=30;
print("The value : $x\n");
print('The value : '.$x);
print("Hello" x 3);
print(1..10);
