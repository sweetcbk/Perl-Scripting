@list=split(" ","This is using split function test");


splice(@list,2,3,"aaaa","bbb","cccc","ddd");
print"After splicing array for replacement\n";
print "@list";