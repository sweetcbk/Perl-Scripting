print "Do until demo";
do{
   print "enter number";
   $num=<>;
   print "The number: $num";
}until($num <15) 