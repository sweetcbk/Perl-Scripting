print "Do while demo";
do{
   print "enter number";
   $num=<>;
   print "The number: $num";
}while($num <15) 